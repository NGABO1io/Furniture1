<!-- header area -->
<?php include('connection.php'); ?>

<?php include('theme/header.php'); ?>

<?php include('theme/sidebar.php'); ?>

<?php include('theme/breadcrumbs.php'); ?>



 <?php include('theme/areachart.php'); ?> 



<?php include('theme/stickyfooter.php'); ?>


